package com.example.bunmonyoudom.myfirstpro;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkbox);
        addListenerOnButton();
    }

    // label and textbox
    public void onClickButton(View v){
        EditText e1 = (EditText)findViewById(R.id.num1);
        EditText e2 = (EditText)findViewById(R.id.num2);
        TextView r  = (TextView)findViewById(R.id.result);

        int num1 = Integer.parseInt(e1.getText().toString());
        int num2 = Integer.parseInt(e2.getText().toString());
        int re   = num1+num2;
        r.setText(re+"");
    }
    //check box
    private CheckBox check1,check2,check3;
    private Button btn_show;
    public void addListenerOnButton(){
        check1= (CheckBox)findViewById(R.id.checkBox);
        check2= (CheckBox)findViewById(R.id.checkBox2);
        check3= (CheckBox)findViewById(R.id.checkBox3);
        btn_show= (Button)findViewById(R.id.button2);

        btn_show.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                StringBuffer myresult = new StringBuffer();
                myresult.append("Dog: ").append(check2.isChecked());
                myresult.append("\nCat: ").append(check1.isChecked());
                myresult.append("\nCow: ").append(check3.isChecked());
                Toast.makeText(MainActivity.this,myresult.toString(),Toast.LENGTH_LONG).show();
            }
        });
    }

}
